"""asyncio-based HTTP server for MCP Security Gateway Monitor.

Provides versioned API endpoints integrating all production components:
config, logging, circuit breakers, rate limiting, alerting, metrics,
tracing, shadow mode, and graceful shutdown.
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
import time
from secrets import compare_digest
from typing import Any
from uuid import uuid4

from mcp_monitor.audit.log import AuditEntry, AuditLog
from mcp_monitor.audit.wal import WriteAheadLog
from mcp_monitor.monitor import MCPSecurityMonitor
from mcp_monitor.production.alerting import AlertingHook
from mcp_monitor.production.circuit_breaker import CircuitBreaker
from mcp_monitor.production.config import Config
from mcp_monitor.production.identity_telemetry import (
    build_event,
    build_single_event_envelope,
    iso8601_utc,
    resolve_source_ip,
)
from mcp_monitor.production.logging import get_logger
from mcp_monitor.production.metrics import MetricsCollector
from mcp_monitor.production.rate_limiter import RateLimiter
from mcp_monitor.production.shutdown import GracefulShutdown
from mcp_monitor.production.tracing import Tracer

_MAX_REQUEST_LINE_BYTES = 8 * 1024
_MAX_HEADER_LINE_BYTES = 8 * 1024
_MAX_HEADER_BYTES = 32 * 1024
_MAX_HEADER_COUNT = 100


class ProductionServer:
    """asyncio HTTP server with full production infrastructure.

    Integrates configuration, logging, circuit breakers, rate limiting,
    alerting, metrics, tracing, shadow mode, and graceful shutdown.
    """

    def __init__(self, config: Config | None = None) -> None:
        self.config = config or Config()
        self._logger = get_logger(
            "mcp_monitor.production.server",
            level=self.config.log_level,
        )

        # Set up core monitor
        wal_path = self.config.wal_path or os.path.join(
            tempfile.gettempdir(), "mcp_monitor_wal.jsonl"
        )
        audit_path = self.config.audit_path or os.path.join(
            tempfile.gettempdir(), "mcp_monitor_audit.jsonl"
        )
        self._wal = WriteAheadLog(wal_path)
        self._audit_log = AuditLog(log_file=audit_path)
        self._monitor = MCPSecurityMonitor(
            allowed_servers=self.config.allowed_servers,
            audit_log=self._audit_log,
            max_payload_kb=self.config.max_payload_kb,
        )

        # Production components
        self._rate_limiter = RateLimiter(tokens_per_minute=self.config.rate_limit_rpm)
        self._metrics = MetricsCollector()
        self._tracer = Tracer()
        self._alerting = AlertingHook(
            webhook_url=self.config.webhook_url,
            risk_threshold=80,
        )
        self._circuit_breaker = CircuitBreaker(
            name="inspect_call",
            failure_threshold=self.config.circuit_breaker_threshold,
            recovery_timeout=self.config.circuit_breaker_timeout,
        )
        self._output_circuit_breaker = CircuitBreaker(
            name="inspect_output",
            failure_threshold=self.config.circuit_breaker_threshold,
            recovery_timeout=self.config.circuit_breaker_timeout,
        )
        self._shutdown = GracefulShutdown(
            drain_timeout=30.0,
            on_shutdown=self._flush_wal,
        )

        self._server: asyncio.Server | None = None

    def _flush_wal(self) -> None:
        """Flush the WAL during shutdown."""
        try:
            self._wal.checkpoint()
            self._logger.info("WAL flushed successfully")
        except Exception as exc:
            self._logger.error(f"WAL flush failed: {exc}")

    async def start(self) -> None:
        """Start the HTTP server."""
        loop = asyncio.get_event_loop()

        # Register signal handlers (only on Unix-like systems)
        try:
            self._shutdown.register_signals_async(loop)
        except NotImplementedError:
            # Windows doesn't support add_signal_handler
            pass

        self._server = await asyncio.start_server(
            self._handle_connection,
            self.config.listen_host,
            self.config.listen_port,
        )
        self._logger.info(
            f"Server started on port {self.config.listen_port}",
            extra={
                "extra_fields": {
                    "host": self.config.listen_host,
                    "port": self.config.listen_port,
                    "shadow_mode": self.config.shadow_mode,
                }
            },
        )

        async with self._server:
            try:
                await self._server.serve_forever()
            except asyncio.CancelledError:
                pass
            finally:
                await self._graceful_shutdown()

    async def _graceful_shutdown(self) -> None:
        """Execute graceful shutdown sequence."""
        self._shutdown.execute_shutdown()

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle a single HTTP connection."""
        get_extra_info = getattr(writer, "get_extra_info", None)
        peername = get_extra_info("peername") if callable(get_extra_info) else None
        if isinstance(peername, tuple | list) and peername:
            peer_address = str(peername[0])
        elif peername:
            peer_address = str(peername)
        else:
            peer_address = ""

        try:
            request_line = await asyncio.wait_for(reader.readline(), timeout=30.0)
            if not request_line:
                writer.close()
                return
            if len(request_line) > _MAX_REQUEST_LINE_BYTES or not request_line.endswith(b"\n"):
                await self._send_response(writer, 414, {"error": "Request line too long"})
                return

            # Parse a strict origin-form HTTP request line. The gateway does not
            # support proxy-form absolute URIs or ambiguous HTTP framing.
            try:
                request_str = request_line.decode("ascii").strip()
            except UnicodeDecodeError:
                await self._send_response(writer, 400, {"error": "Invalid request line"})
                return
            parts = request_str.split()
            if len(parts) != 3:
                await self._send_response(writer, 400, {"error": "Bad request"})
                return

            method, path, http_version = parts
            method = method.upper()
            if method not in {"GET", "POST"}:
                await self._send_response(writer, 405, {"error": "Method not allowed"})
                return
            if http_version not in {"HTTP/1.0", "HTTP/1.1"}:
                await self._send_response(writer, 505, {"error": "HTTP version not supported"})
                return
            if not path.startswith("/") or path.startswith("//") or "://" in path:
                await self._send_response(writer, 400, {"error": "Invalid request target"})
                return

            # Read headers with strict size/count/duplicate framing checks.
            headers: dict[str, str] = {}
            total_header_bytes = 0
            header_count = 0
            while True:
                header_line = await asyncio.wait_for(reader.readline(), timeout=10.0)
                if not header_line:
                    await self._send_response(writer, 400, {"error": "Unexpected EOF in headers"})
                    return
                if len(header_line) > _MAX_HEADER_LINE_BYTES:
                    await self._send_response(writer, 431, {"error": "Header line too large"})
                    return
                total_header_bytes += len(header_line)
                header_count += 1
                if total_header_bytes > _MAX_HEADER_BYTES or header_count > _MAX_HEADER_COUNT:
                    await self._send_response(writer, 431, {"error": "Request headers too large"})
                    return
                if header_line in {b"\r\n", b"\n"}:
                    break
                try:
                    header_str = header_line.decode("ascii").rstrip("\r\n")
                except UnicodeDecodeError:
                    await self._send_response(writer, 400, {"error": "Invalid header encoding"})
                    return
                if ":" not in header_str:
                    await self._send_response(writer, 400, {"error": "Malformed header"})
                    return
                key, value = header_str.split(":", 1)
                normalized_key = key.strip().lower()
                if not normalized_key or any(ch.isspace() for ch in normalized_key):
                    await self._send_response(writer, 400, {"error": "Malformed header name"})
                    return
                if (
                    normalized_key in {"content-length", "transfer-encoding"}
                    and normalized_key in headers
                ):
                    await self._send_response(writer, 400, {"error": "Ambiguous request framing"})
                    return
                headers[normalized_key] = value.strip()

            if "transfer-encoding" in headers:
                # Chunked request bodies are intentionally unsupported by this
                # small control-plane server. Reject instead of attempting to
                # normalize mixed framing.
                await self._send_response(writer, 400, {"error": "Transfer-Encoding unsupported"})
                return

            # Read body if content-length specified.
            body = b""
            raw_content_length = headers.get("content-length", "0")
            try:
                content_length = int(raw_content_length)
            except ValueError:
                await self._send_response(writer, 400, {"error": "Invalid Content-Length"})
                return
            if content_length < 0:
                await self._send_response(writer, 400, {"error": "Invalid Content-Length"})
                return
            if method == "GET" and content_length:
                await self._send_response(writer, 400, {"error": "GET body not supported"})
                return
            if content_length > 0:
                max_bytes = int(self.config.max_payload_kb * 1024)
                if content_length > max_bytes:
                    await self._send_response(writer, 413, {"error": "Payload too large"})
                    return
                body = await asyncio.wait_for(reader.readexactly(content_length), timeout=30.0)

            # Check shutdown
            if self._shutdown.is_shutting_down:
                await self._send_response(writer, 503, {"error": "Server shutting down"})
                return

            # Determine if this is an operational endpoint that should
            # bypass rate limiting (health probes, readiness checks,
            # metrics scrapes). These must remain available even under
            # load to prevent Kubernetes from marking pods as unready.
            _RATE_LIMIT_EXEMPT_PATHS = {"/v1/health", "/v1/ready", "/v1/metrics"}
            if path not in _RATE_LIMIT_EXEMPT_PATHS:
                # Rate limiting (only for non-operational endpoints)
                if not self._rate_limiter.allow():
                    self._metrics.inc_error()
                    await self._send_response(writer, 429, {"error": "Rate limit exceeded"})
                    return

            # Route request
            self._shutdown.request_started()
            self._metrics.inc_active()
            self._metrics.inc_request(path)
            start_time = time.monotonic()
            request_started_at = time.time()

            # Tracing
            traceparent = headers.get("traceparent", "")
            parsed_tp = self._tracer.parse_traceparent(traceparent)
            if parsed_tp:
                trace_id = parsed_tp["trace_id"]
                parent_span_id = parsed_tp["parent_span_id"]
            else:
                trace_id = self._tracer.start_trace()
                parent_span_id = None

            span = self._tracer.start_span(
                name=f"{method} {path}",
                trace_id=trace_id,
                parent_span_id=parent_span_id,
            )

            source_event_id = (
                str(uuid4())
                if method == "POST"
                and path in {"/v1/inspect_call", "/v1/inspect_output", "/api/scan"}
                else None
            )

            try:
                status, response_body = await self._route(
                    method,
                    path,
                    body,
                    headers,
                    trace_id,
                    span.span_id,
                    source_event_id=source_event_id,
                )
                span.set_attribute("http.status_code", status)
                if status >= 400:
                    span.set_status("ERROR")
                    self._metrics.inc_error()
            except Exception as exc:
                self._logger.error(f"Request handling error: {exc}")
                status = 500
                response_body = {"error": "Internal server error"}
                span.set_status("ERROR")
                self._metrics.inc_error()
            finally:
                self._tracer.end_span(span)
                duration = time.monotonic() - start_time
                self._metrics.observe_duration(duration)
                self._metrics.dec_active()
                self._shutdown.request_finished()

            if (
                self.config.identity_telemetry_enabled
                and method == "POST"
                and path in {"/v1/inspect_call", "/v1/inspect_output", "/api/scan"}
            ):
                credential = self._match_api_key(headers)
                if credential is not None:
                    endpoint = "/v1/inspect_call" if path == "/api/scan" else path
                    self._write_identity_telemetry_event(
                        endpoint=endpoint,
                        credential=credential,
                        headers=headers,
                        peer_address=peer_address,
                        request_started_at=request_started_at,
                        latency_ms=max(0, int(round(duration * 1000))),
                        status=status,
                        event_id=source_event_id or f"{trace_id}:{span.span_id}",
                    )

            # Add trace headers to response
            response_headers = {
                "X-Trace-Id": trace_id,
                "X-Span-Id": span.span_id,
                "traceparent": self._tracer.create_traceparent(trace_id, span.span_id),
            }

            await self._send_response(writer, status, response_body, extra_headers=response_headers)

        except (asyncio.TimeoutError, ConnectionResetError, BrokenPipeError):
            pass
        except Exception as exc:
            self._logger.error(f"Connection error: {exc}")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _route(
        self,
        method: str,
        path: str,
        body: bytes,
        headers: dict[str, str],
        trace_id: str,
        span_id: str,
        source_event_id: str | None = None,
    ) -> tuple[int, Any]:
        """Route a request to the appropriate handler."""
        # Health check
        if method == "GET" and path == "/v1/health":
            return self._handle_health()

        # Readiness probe
        if method == "GET" and path == "/v1/ready":
            return self._handle_ready()

        # Metrics expose operational/security telemetry and require the service key.
        if method == "GET" and path == "/v1/metrics":
            auth_status = self._authorize(headers)
            if auth_status is not None:
                return auth_status
            return self._handle_metrics()

        # /api/scan is the detection-lab alias for /v1/inspect_call. It lets the
        # attack-simulation harness (which POSTs tool calls to /api/scan) drive
        # the production gateway so events flow to the SIEM pipeline. Auth is
        # applied the same way as the /v1 endpoints.
        if method == "POST" and path in {"/v1/inspect_call", "/v1/inspect_output", "/api/scan"}:
            auth_status = self._authorize(headers)
            if auth_status is not None:
                return auth_status
            effective_path = "/v1/inspect_call" if path == "/api/scan" else path
            self._record_wal_event(
                effective_path,
                body,
                trace_id,
                span_id,
                entry_id=source_event_id,
            )
            if effective_path == "/v1/inspect_call":
                return self._handle_inspect_call(body, trace_id, span_id)
            return self._handle_inspect_output(body, trace_id, span_id)
        return 404, {"error": "Not found"}

    def _match_api_key(self, headers: dict[str, str]) -> str | None:
        """Return the supplied credential when it matches a configured stable key."""
        supplied = headers.get("x-api-key", "")
        if not supplied:
            return None
        for configured in self.config.api_keys:
            if compare_digest(supplied, configured):
                return supplied
        return None

    def _authorize(self, headers: dict[str, str]) -> tuple[int, dict[str, str]] | None:
        """Authorize protected inspection endpoints."""
        if self.config.allow_anonymous:
            return None
        if not self.config.api_keys:
            self._metrics.inc_error()
            return 503, {"error": "MCP_API_KEY is not configured"}
        if self._match_api_key(headers) is None:
            self._metrics.inc_error()
            return 401, {"error": "Unauthorized"}
        return None

    def _record_wal_event(
        self,
        path: str,
        body: bytes,
        trace_id: str,
        span_id: str,
        *,
        entry_id: str | None = None,
    ) -> None:
        """Persist protected request metadata to WAL before processing."""
        import hashlib

        entry_kwargs: dict[str, Any] = {
            "event_type": "production_request_received",
            "data": {
                "path": path,
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "body_bytes": len(body),
                "trace_id": trace_id,
                "span_id": span_id,
            },
            "prev_hash": "0" * 64,
        }
        if entry_id is not None:
            entry_kwargs["entry_id"] = entry_id
        entry = AuditEntry(**entry_kwargs)
        entry.entry_hash = entry.compute_hash()
        self._wal.write(entry)

    def _write_identity_telemetry_event(
        self,
        *,
        endpoint: str,
        credential: str,
        headers: dict[str, str],
        peer_address: str,
        request_started_at: float,
        latency_ms: int,
        status: int,
        event_id: str,
    ) -> None:
        """Append one privacy-preserving identity telemetry event to the local delivery queue.

        The request path never sends raw credentials or raw addresses to
        external validation. Source selection happens locally, forwarded addresses are used
        only behind explicitly trusted proxy CIDRs, and only fingerprinted event
        fields are written to the queue.
        """
        if (
            not self.config.identity_telemetry_enabled
            or not self.config.identity_telemetry_tenant_salt
            or not self.config.identity_telemetry_output
            or not peer_address
        ):
            return

        try:
            source_ip = resolve_source_ip(
                peer_address,
                headers.get("x-forwarded-for"),
                self.config.trusted_proxy_cidrs,
            )
            event = build_event(
                ts=iso8601_utc(request_started_at),
                credential=credential,
                endpoint=endpoint,
                tokens_in=0,
                tokens_out=0,
                latency_ms=latency_ms,
                status=status,
                source_ip=source_ip,
                tenant_salt=self.config.identity_telemetry_tenant_salt,
                cost=None,
            )
            envelope = build_single_event_envelope(
                event=event,
                event_id=event_id,
                tenant_salt=self.config.identity_telemetry_tenant_salt,
            )
            output_path = self.config.identity_telemetry_output
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            with open(output_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(envelope, separators=(",", ":")) + "\n")
        except Exception as exc:
            # Telemetry is observation-only and must not break MCP inspection.
            # Invalid/untrusted source values are dropped before fingerprinting.
            self._logger.error(f"Identity telemetry event dropped: {exc}")

    def _handle_health(self) -> tuple[int, dict[str, Any]]:
        """GET /v1/health - Health check endpoint."""
        return 200, {
            "status": "healthy",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

    def _handle_ready(self) -> tuple[int, dict[str, Any]]:
        """GET /v1/ready - Require both forensic persistence paths to be writable."""
        try:
            paths = {
                "WAL": self.config.wal_path
                or os.path.join(tempfile.gettempdir(), "mcp_monitor_wal.jsonl"),
                "audit": self.config.audit_path
                or os.path.join(tempfile.gettempdir(), "mcp_monitor_audit.jsonl"),
            }
            for label, path in paths.items():
                parent = os.path.dirname(path) or "."
                if not os.path.isdir(parent) or not os.access(parent, os.W_OK):
                    return 503, {
                        "status": "not_ready",
                        "reason": f"{label} directory not writable",
                    }
            return 200, {"status": "ready"}
        except Exception as exc:
            self._logger.error("Readiness check failed: %s", exc)
            return 503, {"status": "not_ready", "reason": "readiness_check_failed"}

    def _handle_metrics(self) -> tuple[int, str]:
        """GET /v1/metrics - Prometheus text exposition format."""
        # Update circuit breaker states
        self._metrics.set_circuit_state("inspect_call", self._circuit_breaker.state.value)
        self._metrics.set_circuit_state("inspect_output", self._output_circuit_breaker.state.value)
        return 200, self._metrics.expose()

    def _handle_inspect_call(
        self, body: bytes, trace_id: str, span_id: str
    ) -> tuple[int, dict[str, Any]]:
        """POST /v1/inspect_call - Forward to MCPSecurityMonitor."""
        try:
            tool_call = json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError) as exc:
            # RecursionError: attacker-controlled deeply nested JSON exhausts the
            # decoder's recursion limit. This is malformed *client* input, not a
            # server fault, so it must be a 400 (not a 500) and must not leak a
            # stack trace or inflate server-error metrics.
            return 400, {"error": f"Invalid JSON: {type(exc).__name__}"}

        # Use circuit breaker
        try:
            result = self._circuit_breaker.call(
                self._monitor.inspect_call,
                tool_call,
                fallback=lambda tc: {
                    "allowed": False,
                    "risk_score": 100,
                    "findings": ["circuit_breaker_open_fail_closed"],
                    "call_id": "circuit-open",
                },
            )
        except Exception as exc:
            self._logger.error(f"inspect_call failed: {exc}")
            return 500, {"error": "Internal processing error"}

        # Shadow mode: log but always allow
        if self.config.shadow_mode:
            self._logger.info(
                "Shadow mode: findings logged but not blocking",
                extra={
                    "extra_fields": {
                        "trace_id": trace_id,
                        "original_allowed": result.get("allowed"),
                        "risk_score": result.get("risk_score"),
                        "findings": result.get("findings"),
                    }
                },
            )
            result["allowed"] = True
            result["shadow_mode"] = True

        # Alert on critical findings
        self._alerting.check_and_alert(result)

        # Add trace context to response
        result["trace_id"] = trace_id
        result["span_id"] = span_id

        # Emit a SIEM event (NDJSON) for the detection-engineering lab pipeline.
        self._write_siem_event(result, trace_id, span_id)

        return 200, result

    def _write_siem_event(self, result: dict[str, Any], trace_id: str, span_id: str) -> None:
        """Append a single NDJSON security event for Filebeat/Elasticsearch.

        No-op unless MCP_SIEM_ENABLED is set and MCP_SIEM_OUTPUT points at a
        writable path. Failures are swallowed: SIEM export must never break the
        inspection request path.
        """
        if not self.config.siem_enabled or not self.config.siem_output:
            return
        try:
            event = {
                "@timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.000000Z", time.gmtime()),
                "event_type": "tool_call_inspected",
                "allowed": result.get("allowed"),
                "decision": "block" if result.get("allowed") is False else "allow",
                "risk_score": result.get("risk_score"),
                "findings": result.get("findings", []),
                "detector": result.get("detector"),
                "call_id": result.get("call_id"),
                "trace_id": trace_id,
                "span_id": span_id,
            }
            output_path = self.config.siem_output
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            with open(output_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(event, default=str) + "\n")
        except Exception as exc:  # noqa: BLE001 - SIEM export is best-effort
            self._logger.error(f"SIEM event write failed: {exc}")

    def _handle_inspect_output(
        self, body: bytes, trace_id: str, span_id: str
    ) -> tuple[int, dict[str, Any]]:
        """POST /v1/inspect_output - Forward to MCPSecurityMonitor."""
        try:
            payload = json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError) as exc:
            # RecursionError: attacker-controlled deeply nested JSON exhausts the
            # decoder's recursion limit. This is malformed *client* input, not a
            # server fault, so it must be a 400 (not a 500) and must not leak a
            # stack trace or inflate server-error metrics.
            return 400, {"error": f"Invalid JSON: {type(exc).__name__}"}

        tool_name = payload.get("tool_name", "")
        output = payload.get("output", {})

        # Use circuit breaker for graceful degradation
        try:
            result = self._output_circuit_breaker.call(
                self._monitor.inspect_output,
                tool_name,
                output,
                fallback=lambda tn, out: {
                    "allowed": False,
                    "risk_score": 100,
                    "findings": ["circuit_breaker_open_fail_closed"],
                    "tool_name": tn,
                },
            )
        except Exception as exc:
            self._logger.error(f"inspect_output failed: {exc}")
            return 500, {"error": "Internal processing error"}

        # Shadow mode
        if self.config.shadow_mode:
            self._logger.info(
                "Shadow mode: output findings logged but not blocking",
                extra={
                    "extra_fields": {
                        "trace_id": trace_id,
                        "original_allowed": result.get("allowed"),
                        "risk_score": result.get("risk_score"),
                        "findings": result.get("findings"),
                    }
                },
            )
            result["allowed"] = True
            result["shadow_mode"] = True

        # Alert on critical findings
        self._alerting.check_and_alert(result)

        # Add trace context
        result["trace_id"] = trace_id
        result["span_id"] = span_id

        return 200, result

    async def _send_response(
        self,
        writer: asyncio.StreamWriter,
        status: int,
        body: Any,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        """Send an HTTP response."""
        status_messages = {
            200: "OK",
            400: "Bad Request",
            404: "Not Found",
            405: "Method Not Allowed",
            413: "Payload Too Large",
            414: "URI Too Long",
            429: "Too Many Requests",
            431: "Request Header Fields Too Large",
            500: "Internal Server Error",
            503: "Service Unavailable",
            505: "HTTP Version Not Supported",
        }
        status_msg = status_messages.get(status, "Unknown")

        if isinstance(body, str):
            body_bytes = body.encode("utf-8")
            content_type = "text/plain; charset=utf-8"
        else:
            body_bytes = json.dumps(body, default=str).encode("utf-8")
            content_type = "application/json"

        headers = [
            f"HTTP/1.1 {status} {status_msg}",
            f"Content-Type: {content_type}",
            f"Content-Length: {len(body_bytes)}",
            "Connection: close",
        ]
        if extra_headers:
            for key, value in extra_headers.items():
                headers.append(f"{key}: {value}")

        response = "\r\n".join(headers) + "\r\n\r\n"
        writer.write(response.encode("utf-8") + body_bytes)
        await writer.drain()


def run_server(config: Config | None = None) -> None:
    """Entry point to run the production server."""
    server = ProductionServer(config=config)
    asyncio.run(server.start())


def main() -> None:
    """Run the production API with environment-based configuration."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Run the MCP Security Gateway production API on port 8080 by default."
    )
    parser.add_argument("--version", action="version", version="mcp-security-gateway-monitor 0.1.0")
    parser.parse_args()
    run_server()
